#!/bin/bash
# NemoClaw™ Security Hardening Script v1.0.5
# Mandatory Security Lockdown for Enterprise Deployment

set -e
LOG_FILE="/tmp/nemoclaw_security.log"

log() {
    echo -e "[SECURITY] $(date +'%H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        log "❌ Error: This script must be run as root (sudo)."
        exit 1
    fi
}

lockdown_firewall() {
    log "🔥 Configuring UFW Firewall profiles..."
    if command -v ufw &> /dev/null; then
        # Default policy: deny all
        ufw default deny incoming
        ufw default allow outgoing
        
        # Allow only orchestrations ports
        ufw allow 22/tcp # SSH
        ufw allow 8080/tcp # NemoClaw Master
        ufw allow 8081/tcp # NemoClaw Agent
        
        # Rate limit SSH for brute force protection
        ufw limit ssh
        
        ufw --force enable
        log "✅ Firewall enabled and hardened with restricted ports."
    else
        log "⚠️ Warning: ufw not found. Skipping firewall setup."
    fi
}

secure_folders() {
    log "📂 Securing NemoClaw system directories..."
    chmod 700 /var/log/nemoclaw || log "ℹ️ Log dir not found, skipping chmod."
    chmod 600 ~/.nemoclaw/policies/*.json || log "ℹ️ Policies not found, skipping chmod."
    chmod 600 ~/.nemoclaw/blueprints/*.json || log "ℹ️ Blueprints not found, skipping chmod."
    log "✅ Directory permissions hardened to 700/600."
}

disable_root_login() {
    log "💀 Disabling SSH root login (optional)..."
    sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin no/' /etc/ssh/sshd_config || log "ℹ️ SSH config not editable, skipping."
    # systemctl restart ssh || log "ℹ️ Not using systemd, skipping ssh restart."
}

main() {
    echo "=========================================="
    echo "   NemoClaw™ Security Hardening Kit"
    echo "=========================================="
    check_root
    lockdown_firewall
    secure_folders
    disable_root_login
    log "✨ Security hardening applied! Log: $LOG_FILE"
    echo "------------------------------------------"
    echo "Sytsem is now LOCKED DOWN according to"
    echo "NemoClaw enterprise security standards."
}

main
