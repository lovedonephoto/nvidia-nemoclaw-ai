#!/bin/bash
# NemoClaw™ Professional Hybrid Installer v2.1
# Supports: Ubuntu 20.04+, macOS (Apple Silicon M1/M2/M3)
# Optimized for NVIDIA GPU and Apple Metal Acceleration

set -e
LOG_FILE="/tmp/nemoclaw_install.log"

log() {
    echo -e "[$(date +'%H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

check_os() {
    OS="$(uname -s)"
    case "${OS}" in
        Linux*)     OS_TYPE=LINUX;;
        Darwin*)    OS_TYPE=MAC;;
        *)          OS_TYPE="UNKNOWN"
    esac
    log "💻 Detected Operating System: ${OS_TYPE}"
}

detect_gpu() {
    if [[ "$OS_TYPE" == "LINUX" ]]; then
        if command -v nvidia-smi &> /dev/null; then
            GPU_MODEL=$(nvidia-smi --query-gpu=name --format=csv,noheader)
            log "💎 NVIDIA GPU Detected: ${GPU_MODEL}"
        else
            log "⚠️ Warning: NVIDIA GPU not detected. CPU mode fallback."
        fi
    elif [[ "$OS_TYPE" == "MAC" ]]; then
        GPU_MODEL=$(system_profiler SPDisplaysDataType | grep "Chipset Model" | head -n 1 | cut -d: -f2 | xargs)
        log "🍎 Apple Silicon Detected: ${GPU_MODEL}"
    fi
}

install_deps() {
    if [[ "$OS_TYPE" == "LINUX" ]]; then
        log "📦 Installing Ubuntu dependencies..."
        sudo apt update -qq && sudo apt install -y curl jq unzip docker-compose-plugin &> /dev/null
    elif [[ "$OS_TYPE" == "MAC" ]]; then
        log "📦 Checking Homebrew dependencies..."
        if ! command -v brew &> /dev/null; then
            log "ℹ️ Installing Homebrew..."
            /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        fi
        brew install jq unzip curl docker-compose &> /dev/null
    fi
}

deploy_kit() {
    log "🚀 Deploying NemoClaw Professional Kit structures..."
    mkdir -p ~/.nemoclaw/policies ~/.nemoclaw/blueprints
    cp -r ../policies/* ~/.nemoclaw/policies/
    cp -r ../blueprints/* ~/.nemoclaw/blueprints/
    log "✅ Templates deployed to ~/.nemoclaw"
}

main() {
    echo "=========================================="
    echo "   NemoClaw™ Professional Installer v2.1"
    echo "=========================================="
    check_os
    detect_gpu
    install_deps
    deploy_kit
    log "✨ Installation successful! Log: $LOG_FILE"
    echo "------------------------------------------"
    echo "NEXT STEP: Run 'sudo bash scripts/hardened-setup.sh'"
    echo "to apply enterprise security policies."
}

main
