# NemoClaw™ Professional Setup Kit (V2.1)
**NVIDIA Powered AI Agent Infrastructure - Enterprise Distribution**

This official setup kit provides everything needed to deploy a hardened, GPU-accelerated NemoClaw AI agent environment within 5 minutes. Optimized for **Apple Silicon (M1/M2/M3)** and **NVIDIA GPU (Ubuntu)**.

---

## 📂 Folder Structure
| Folder | Purpose |
| :--- | :--- |
| `/blueprints` | Pre-configured AI Agent personalities and goal sets (Market Analyst, Security Auditor). |
| `/docker` | Professional orchestration files (docker-compose, Dockerfile, env) with GPU acceleration. |
| `/documents` | **Mandatory Reading:** Hardening Guide (PDF Source) and Quickstart Manual. |
| `/policies` | 4 Enterprise-grade security policies (JSON) for restricted agent execution. |
| `/scripts` | Automated hybrid (Mac/Ubuntu) installer and security hardening scripts. |

---

## 🛠️ Installation (5 Minutes)
1. **Unzip the kit:** `unzip setup-kit.zip -d nemo-setup && cd nemo-setup`
2. **Run Installer:** `bash scripts/install.sh` (Auto-detects GPU and OS)
3. **Lockdown Security:** `sudo bash scripts/hardened-setup.sh` (Mandatory for production)

---

## 🚀 Key Features (Enterprise v2.1)
- **Zero-Trust Networking:** Pre-configured egress filtering for all agents.
- **Mac Optimization:** Native support for Metal GPU acceleration on Apple Silicon.
- **NVIDIA Integration:** Seamless Docker-ready NVIDIA Container Toolkit configs.
- **Audit Trails:** Mandatory AES-256 encrypted logging for all administrative actions.

---

## 🆘 Support
For premium support, security auditing, or large-scale deployment consulting:
- **Email:** `soylamistugce@gmail.com`
- **Docs:** See `documents/Quickstart_Guide.md` for detailed commands.

---
© 2026 NemoClaw AI App. All rights reserved.
Proudly built on NVIDIA Nemo infrastructure.
