# NemoClaw™ Enterprise Hardening & Security Guide (V2.1)
**Confidential - Internal Use Only**

## 1. Introduction
This guide outlines the mandatory security configurations required to deploy and maintain a hardened NemoClaw AI agent infrastructure. Following Peter Steinberger's original principles, security is at the core of our enterprise distribution.

## 2. Infrastructure Hardening
### 2.1 Firewall Configuration (UFW/IPtables)
All NemoClaw nodes must restrict ingress traffic. Only the orchestration port (default: 8080) should be reachable from authorized jump hosts.

```bash
# Example UFW Rules
ufw default deny incoming
ufw allow from 10.0.0.x to any port 8080 proto tcp
ufw enable
```

### 2.2 Network Egress Filtering
Agents must not be allowed full internet access. Use the provided policies in `/policies/` to restrict egress to validated NVIDIA, HuggingFace, and Python repository endpoints.

## 3. Data Encryption
### 3.1 At-Rest (AES-256)
All state-management data stored in `/sandbox/` must be encrypted using AES-256-GCM. 

### 3.2 In-Transit (TLS 1.3)
All communication between NemoClaw nodes and the building infrastructure must be forced over TLS 1.3.

## 4. Resource Isolation (Sandboxing)
Always use the `NemoClaw-Data-Analyst-Pro` policy for non-administrative agents. This ensures `no-access` to system critical paths like `/etc/shadow` or `~/.ssh/`.

## 5. Audit Logging & Monitoring
Enable `monitor_process_spawn` in the agent configuration to detect any unauthorized binary execution. Logs should be forwarded to your enterprise SIEM via the `audit_backend` URL provided in the `admin-policy`.

## 6. Compliance Checklist
- [ ] SSH root login disabled
- [ ] Agents running as non-privileged users
- [ ] VRAM memory limit applied per agent
- [ ] Audit-trail backend connectivity verified

---
© 2026 NemoClaw AI App. All rights reserved.
