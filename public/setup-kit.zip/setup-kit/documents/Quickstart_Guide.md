# NemoClaw™ Professional Quickstart Guide (V2.1)
**Getting Started with Professional Setup Kit**

## 1. Prerequisites
- **Ubuntu 20.04+** or **macOS (Apple Silicon M1/M2/M3)**
- **NVIDIA Driver 535+** (for GPU nodes)
- **Docker 24+** (with NVIDIA Container Toolkit)

## 2. Installation (5 Minutes)
Unzip the `setup-kit.zip` and run the optimized installation script:

```bash
# Extract the kit
unzip setup-kit.zip -d nemo-setup && cd nemo-setup

# Run the installation
sudo bash scripts/install.sh
```

## 3. Applying Security Policies
Before running any agent, apply the required security policy from the `/policies/` folder:

```bash
# Example: Deploying an Analyst Agent
nemoclaw agent create --policy policies/data-analyst-policy.json
```

## 4. Running Your First Blueprint
We've included two pre-configured blueprints in `/blueprints/`. To start the Market Intelligence agent:

```bash
# Start the agent using the blueprint
nemoclaw run blueprints/market-intelligence-blueprint.json
```

## 5. Docker Deployment (Optional)
For professional production environments, we recommend using the provided Docker configurations:

```bash
# Start the full stack with GPU acceleration
cd docker
docker-compose up -d
```

## 6. Accessing Local Dashboards
- **Orchestration Dashboard:** `http://localhost:8080`
- **Agent Monitoring:** `http://localhost:8081`

## 7. Support & Troubleshooting
Check the `NemoClaw_Hardening_Guide.pdf` for deep-dive security setup or contact support at `soylamistugce@gmail.com`.

---
© 2026 NemoClaw AI App. All rights reserved.
